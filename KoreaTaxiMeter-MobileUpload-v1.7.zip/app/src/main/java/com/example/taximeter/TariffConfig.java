package com.example.taximeter;

import android.content.Context;
import android.content.SharedPreferences;

public class TariffConfig {
    private final SharedPreferences p;
    public TariffConfig(Context c){ p=c.getSharedPreferences("tariff",Context.MODE_PRIVATE); }
    public int baseFare(){return p.getInt("baseFare",4800);}
    public int baseDistanceM(){return p.getInt("baseDistanceM",1600);}
    public int distanceUnitFare(){return p.getInt("distanceUnitFare",100);}
    public int distanceUnitM(){return p.getInt("distanceUnitM",131);}
    public int timeUnitFare(){return p.getInt("timeUnitFare",100);}
    public int timeUnitSec(){return p.getInt("timeUnitSec",30);}
    public float lowSpeedKmh(){return p.getFloat("lowSpeedKmh",15.72f);}
    public int nightPct(){return p.getInt("nightPct",20);}
    public int nightPeakPct(){return p.getInt("nightPeakPct",40);}
    public int outPct(){return p.getInt("outPct",20);}
    public String nightStart(){return p.getString("nightStart","22:00");}
    public String nightEnd(){return p.getString("nightEnd","04:00");}
    public boolean autoNight(){return p.getBoolean("autoNight",true);}
    public void save(int base,int baseM,int df,int dm,int tf,int ts,float low,int np,int npp,int op,String ns,String ne,boolean an){
        p.edit().putInt("baseFare",base).putInt("baseDistanceM",baseM)
         .putInt("distanceUnitFare",df).putInt("distanceUnitM",dm)
         .putInt("timeUnitFare",tf).putInt("timeUnitSec",ts)
         .putFloat("lowSpeedKmh",low).putInt("nightPct",np).putInt("nightPeakPct",npp)
         .putInt("outPct",op).putString("nightStart",ns).putString("nightEnd",ne)
         .putBoolean("autoNight",an).apply();
    }
    public boolean outOfArea(){return p.getBoolean("outOfArea",false);}
    public void setOutOfArea(boolean v){p.edit().putBoolean("outOfArea",v).apply();}
    public void setAutoNight(boolean v){p.edit().putBoolean("autoNight",v).apply();}
}
